
import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { requireAdmin } from '../middleware/auth.js';

const router = Router();
router.use(requireAdmin);

// --- Preparation Books ---
router.post('/books', async (req, res, next) => {
    try {
        const newItemData = req.body;
        const id = uuidv4();
        await req.db.execute(`INSERT INTO PreparationBook (id, title, author, url, imageUrl) VALUES (?, ?, ?, ?, ?)`,
            [id, newItemData.title, newItemData.author, newItemData.url, newItemData.imageUrl]
        );
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['Prep Book Added', `Book added: ${newItemData.title}`]);
        res.status(201).json({ id, ...newItemData });
    } catch (error) {
        next(error);
    }
});

router.put('/books', async (req, res, next) => {
    try {
        const { id: bookId, ...updateData } = req.body;
        const [updateResult] = await req.db.execute(`UPDATE PreparationBook SET title = ?, author = ?, url = ?, imageUrl = ? WHERE id = ?`,
            [updateData.title, updateData.author, updateData.url, updateData.imageUrl, bookId]
        );
        if (updateResult.affectedRows === 0) return res.status(404).json({ message: `Book with ID ${bookId} not found.` });
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['Prep Book Updated', `Book updated: ${updateData.title}`]);
        res.status(200).json({ id: bookId, ...updateData });
    } catch (error) {
        next(error);
    }
});

router.delete('/books', async (req, res, next) => {
    try {
        const { id: deleteId } = req.body;
        const [deleteResult] = await req.db.execute(`DELETE FROM PreparationBook WHERE id = ?`, [deleteId]);
        if (deleteResult.affectedRows === 0) return res.status(404).json({ message: `Book with ID ${deleteId} not found.` });
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['Prep Book Deleted', `Book with id ${deleteId} deleted.`]);
        res.status(204).end();
    } catch (error) {
        next(error);
    }
});

// --- Preparation Courses ---
router.post('/courses', async (req, res, next) => {
    try {
        const newItemData = req.body;
        const id = uuidv4();
        await req.db.execute(`INSERT INTO PreparationCourse (id, platform, title, url) VALUES (?, ?, ?, ?)`,
            [id, newItemData.platform, newItemData.title, newItemData.url]
        );
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['Prep Course Added', `Course added: ${newItemData.title}`]);
        res.status(201).json({ id, ...newItemData });
    } catch (error) {
        next(error);
    }
});

router.put('/courses', async (req, res, next) => {
    try {
        const { id: courseId, ...updateData } = req.body;
        const [updateResult] = await req.db.execute(`UPDATE PreparationCourse SET platform = ?, title = ?, url = ? WHERE id = ?`,
            [updateData.platform, updateData.title, updateData.url, courseId]
        );
        if (updateResult.affectedRows === 0) return res.status(404).json({ message: `Course with ID ${courseId} not found.` });
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['Prep Course Updated', `Course updated: ${updateData.title}`]);
        res.status(200).json({ id: courseId, ...updateData });
    } catch (error) {
        next(error);
    }
});

router.delete('/courses', async (req, res, next) => {
    try {
        const { id: deleteId } = req.body;
        const [deleteResult] = await req.db.execute(`DELETE FROM PreparationCourse WHERE id = ?`, [deleteId]);
        if (deleteResult.affectedRows === 0) return res.status(404).json({ message: `Course with ID ${deleteId} not found.` });
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['Prep Course Deleted', `Course with id ${deleteId} deleted.`]);
        res.status(204).end();
    } catch (error) {
        next(error);
    }
});

export default router;