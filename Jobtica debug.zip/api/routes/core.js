
import { Router } from 'express';

const router = Router();

const slugify = (text) => {
  if (!text) return '';
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w\-]+/g, '')
    .replace(/\-\-+/g, '-')
    .replace(/^-+/, '')
    .replace(/-+$/, '');
};


// Helper to parse JSON from DB fields with error handling
const parseJsonField = (jsonString) => {
    if (!jsonString) return [];
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        console.error('Failed to parse JSON field:', e);
        return [];
    }
};

// GET /api/data - Fetch all site data
router.get('/data', async (req, res, next) => {
    try {
        const connection = req.db;
        const [settingsRows] = await connection.execute('SELECT key_name, value FROM KeyValueStore');
        const settingsObject = settingsRows.reduce((acc, row) => {
            acc[row.key_name] = parseJsonField(row.value);
            return acc;
        }, {});

        const [jobs] = await connection.execute('SELECT *, CAST(affiliateCoursesJson AS CHAR) AS affiliateCoursesJson, CAST(affiliateBooksJson AS CHAR) AS affiliateBooksJson FROM Job ORDER BY createdAt DESC');
        const [quickLinks] = await connection.execute('SELECT * FROM QuickLink ORDER BY title ASC');
        const [posts] = await connection.execute('SELECT * FROM ContentPost ORDER BY createdAt DESC');
        const [breakingNews] = await connection.execute('SELECT * FROM BreakingNews');
        const [sponsoredAds] = await connection.execute('SELECT * FROM SponsoredAd');
        const [preparationCourses] = await connection.execute('SELECT * FROM PreparationCourse ORDER BY title ASC');
        const [preparationBooks] = await connection.execute('SELECT * FROM PreparationBook ORDER BY title ASC');
        const [upcomingExams] = await connection.execute('SELECT * FROM UpcomingExam ORDER BY deadline ASC');
        
        const parsedJobs = jobs.map(job => ({
            ...job,
            affiliateCourses: parseJsonField(job.affiliateCoursesJson),
            affiliateBooks: parseJsonField(job.affiliateBooksJson),
        }));
        
        const publicData = {
            jobs: parsedJobs, quickLinks, posts, breakingNews, sponsoredAds,
            preparationCourses, preparationBooks, upcomingExams, ...settingsObject,
        };

        if (req.session.isAdmin) {
            const [subscribers] = await connection.execute('SELECT * FROM Subscriber ORDER BY subscriptionDate DESC');
            const [activityLogs] = await connection.execute('SELECT * FROM ActivityLog ORDER BY timestamp DESC');
            const [contacts] = await connection.execute('SELECT * FROM ContactSubmission ORDER BY submittedAt DESC');
            const [emailNotifications] = await connection.execute('SELECT * FROM EmailNotification ORDER BY sentAt DESC');
            const [customEmails] = await connection.execute('SELECT * FROM CustomEmail ORDER BY sentAt DESC');
            const [emailTemplates] = await connection.execute('SELECT * FROM EmailTemplate ORDER BY name ASC');
            
            res.status(200).json({
                ...publicData,
                subscribers, activityLogs, contacts, emailNotifications, customEmails, emailTemplates,
            });
        } else {
            res.status(200).json({
                ...publicData,
                subscribers: [], activityLogs: [], contacts: [],
                emailNotifications: [], customEmails: [], emailTemplates: [],
            });
        }
    } catch (error) {
        next(error);
    }
});

// GET /api/health - A simple health check endpoint
router.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
});

// GET /api/robots - Serve the robots.txt content dynamically
router.get('/robots', (req, res) => {
    const protocol = req.headers['x-forwarded-proto'] || req.protocol;
    const host = req.get('host');
    const baseURL = `${protocol}://${host}`;

    const robotsContent = `User-agent: *
Allow: /
Sitemap: ${baseURL}/sitemap.xml

Disallow: /admin
Disallow: /api`;
    
    res.setHeader('Content-Type', 'text/plain');
    res.status(200).send(robotsContent);
});

// GET /api/sitemap - Dynamically generate the sitemap.xml
const generateSitemap = (pages) => {
    const urls = pages.map(({ url, lastModified }) => `
        <url>
            <loc>${url}</loc>
            ${lastModified ? `<lastmod>${lastModified}</lastmod>` : ''}
            <changefreq>daily</changefreq>
            <priority>0.8</priority>
        </url>
    `).join('');
    return `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls}</urlset>`;
};

router.get('/sitemap', async (req, res, next) => {
    try {
        const protocol = req.headers['x-forwarded-proto'] || req.protocol;
        const host = req.get('host');
        const baseURL = `${protocol}://${host}`;

        const [jobs] = await req.db.execute(`SELECT title, createdAt FROM Job WHERE status != 'expired'`);
        const [posts] = await req.db.execute(`SELECT id, createdAt FROM ContentPost WHERE status = 'published' AND type = 'posts'`);

        const jobPages = jobs.map(job => ({
            url: `${baseURL}/job/${slugify(job.title)}`,
            lastModified: new Date(job.createdAt).toISOString(),
        }));
        
        const postPages = posts.map(post => ({
            url: `${baseURL}/blog/${post.id}`,
            lastModified: new Date(post.createdAt).toISOString(),
        }));
        
        const staticPages = ['/', '/blog', '/preparation', '/about', '/contact', '/privacy', '/terms', '/disclaimer']
            .map(path => ({ url: `${baseURL}${path}` }));
        
        const allPages = [...staticPages, ...jobPages, ...postPages];
        const sitemap = generateSitemap(allPages);

        res.setHeader('Content-Type', 'text/xml');
        res.status(200).send(sitemap);
    } catch (error) {
        next(error);
    }
});

export default router;
