
import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { requireAdmin } from '../middleware/auth.js';

const router = Router();

// --- Subscribers ---

// POST /api/audience/subscribers - Public endpoint for new subscriptions
router.post('/subscribers', async (req, res, next) => {
    try {
        const { email } = req.body;
        const [existing] = await req.db.execute('SELECT id FROM Subscriber WHERE email = ?', [email]);
        if (existing.length > 0) {
            return res.status(409).json({ message: 'This email is already subscribed.' });
        }
        const id = uuidv4();
        await req.db.execute(`INSERT INTO Subscriber (id, email, status, subscriptionDate) VALUES (?, ?, ?, ?)`,
            [id, email, 'active', new Date()]
        );
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['New Subscriber', `New subscriber: ${email}`]);
        res.status(201).json({ id, email, status: 'active', subscriptionDate: new Date() });
    } catch (error) {
        next(error);
    }
});

// DELETE /api/audience/subscribers - Admin-only endpoint for deleting a subscriber
router.delete('/subscribers', requireAdmin, async (req, res, next) => {
    try {
        const { id: deleteId } = req.body;
        const [deleteResult] = await req.db.execute(`DELETE FROM Subscriber WHERE id = ?`, [deleteId]);
        if (deleteResult.affectedRows === 0) return res.status(404).json({ message: `Subscriber with ID ${deleteId} not found.` });
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['Subscriber Deleted', `Subscriber with id ${deleteId} deleted.`]);
        res.status(204).end();
    } catch (error) {
        next(error);
    }
});


// --- Contacts ---

// POST /api/audience/contacts - Public endpoint for new submissions
router.post('/contacts', async (req, res, next) => {
    try {
        const submissionData = req.body;
        const id = uuidv4();
        const [result] = await req.db.execute(
            `INSERT INTO ContactSubmission (id, name, email, subject, message, submittedAt) VALUES (?, ?, ?, ?, ?, ?)`,
            [id, submissionData.name, submissionData.email, submissionData.subject, submissionData.message, new Date()]
        );
        if (result.affectedRows === 0) throw new Error('Failed to create contact submission.');
        res.status(201).json({ id, submittedAt: new Date(), ...submissionData });
    } catch (error) {
        next(error);
    }
});

// DELETE /api/audience/contacts - Admin-only endpoint for deleting submissions
router.delete('/contacts', requireAdmin, async (req, res, next) => {
    try {
        const { id: deleteId } = req.body;
        const [deleteResult] = await req.db.execute(`DELETE FROM ContactSubmission WHERE id = ?`, [deleteId]);
        if (deleteResult.affectedRows === 0) return res.status(404).json({ message: `Contact Submission with ID ${deleteId} not found.` });
        await req.db.execute('INSERT INTO ActivityLog (action, details) VALUES (?, ?)', ['Contact Deleted', `Contact message with id ${deleteId} deleted.`]);
        res.status(204).end();
    } catch (error) {
        next(error);
    }
});


export default router;
